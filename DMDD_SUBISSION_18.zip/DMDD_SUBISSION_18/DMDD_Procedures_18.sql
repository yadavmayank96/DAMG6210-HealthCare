-----------------------CREate taBLE SPRoc---------------------

CREATE OR REPLACE PROCEDURE remove_objects (
    name_of_object VARCHAR2,
    type_of_object VARCHAR2
) IS
    cnt NUMBER := 0;
BEGIN
    IF upper(type_of_object) = 'TABLE' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_tables
        WHERE
            upper(table_name) = upper(TRIM(name_of_object));

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'drop table '
                              || name_of_object
                              || ' cascade constraints';
        END IF;
    END IF;

    IF upper(type_of_object) = 'PROCEDURE' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_objects
        WHERE
                upper(object_type) = 'PROCEDURE'
            AND upper(object_name) = upper(name_of_object);

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'DROP PROCEDURE ' || name_of_object;
        END IF;
    END IF;

    IF upper(type_of_object) = 'TRIGGER' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_triggers
        WHERE
            upper(trigger_name) = upper(name_of_object);

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'DROP TRIGGER ' || name_of_object;
        END IF;
    END IF;

    IF upper(type_of_object) = 'FUNCTION' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_objects
        WHERE
                upper(object_type) = 'FUNCTION'
            AND upper(object_name) = upper(name_of_object);

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'DROP FUNCTION ' || name_of_object;
        END IF;
    END IF;

    IF upper(type_of_object) = 'SEQUENCE' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_sequences
        WHERE
            upper(sequence_name) = upper(name_of_object);

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'DROP SEQUENCE ' || name_of_object;
        END IF;
    END IF;

    IF upper(type_of_object) = 'VIEW' THEN
        SELECT
            COUNT(*)
        INTO cnt
        FROM
            user_views
        WHERE
            upper(view_name) = upper(name_of_object);

        IF cnt > 0 THEN
            EXECUTE IMMEDIATE 'DROP VIEW ' || name_of_object;
        END IF;
    END IF;

END;

--------------------------------------------------------------
--------------------filtER olders-----------------------------
CREATE OR REPLACE PROCEDURE filter_order_inputs IS

    CURSOR records IS
    SELECT
        *
    FROM
        in_file;

    record_i          in_file%rowtype;
    records_to_filter NUMBER := 0;
    n_orders          NUMBER := 0;
    no_records_to_filter EXCEPTION;
    no_orders EXCEPTION;
BEGIN
    SELECT
        COUNT(*)
    INTO records_to_filter
    FROM
        in_file;

    SELECT
        COUNT(*)
    INTO n_orders
    FROM
        orders;

    IF records_to_filter = 0 THEN
        RAISE no_records_to_filter;
    ELSIF n_orders = 0 THEN
        RAISE no_orders;
    END IF;

    OPEN records;
    LOOP
        FETCH records INTO record_i;
        EXIT WHEN records%notfound;
        DECLARE
            record_present NUMBER := 0;
            flag           NUMBER := 0;
            record_status  VARCHAR2(255) := 'NEW';
        BEGIN
            dbms_output.put_line('---BEGIN---');
            SELECT
                COUNT(*)
            INTO record_present
            FROM
                orders
            WHERE
                order_id = record_i.order_number;

            SELECT
                order_status
            INTO record_status
            FROM
                orders
            WHERE
                order_id = record_i.order_number;

            IF record_i.order_number IS NULL OR record_present = 0 THEN
--                dbms_output.put_line('---BEGIN---');
                flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'order_number_null');
            END IF;

            IF record_i.order_status IS NULL OR upper(record_i.order_status) NOT IN ( 'SHIPPED', 'DELIVERED' ) THEN
                flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'order_status_null');
            END IF;

            IF record_i.patient_number IS NULL THEN
                flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'patient_number_null');
            END IF;

            IF upper(record_status) = 'DELIVERED' THEN
                flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'order_already_delivered');
            END IF;

            IF upper(record_i.order_status) = 'SHIPPED' THEN
                flag := date_check(record_i.ship_date);
--                dbms_output.put_line('---Checking SHIPPING Date---');

                IF flag = 2 THEN
                    flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'shipping_date_invalid');
                ELSE
                    flag := status_update(record_i.order_number);
                    IF flag = 1 THEN
                        dbms_output.put_line('Order Status Updated');
                        dbms_output.put_line(record_i.order_number);
                    ELSE
                        dbms_output.put_line('Error Occured');
                    END IF;

                END IF;

            END IF;

            IF upper(record_i.order_status) = 'DELIVERED' THEN
                flag := date_check(record_i.delivery_date);
--                dbms_output.put_line('---Checking Date---');

                IF flag = 2 THEN
                    flag := error_records_transfer(record_i.order_number, record_i.patient_number, 'delivered_date_invalid');
                ELSE
                    flag := status_update(record_i.order_number);
                    IF flag = 1 THEN
                        dbms_output.put_line('Order Status Updated');
                        dbms_output.put_line(record_i.order_number);
                    ELSE
                        dbms_output.put_line('Error Occured');
                    END IF;

                END IF;

            END IF;

        END;

    END LOOP;

EXCEPTION
    WHEN no_records_to_filter THEN
        dbms_output.put_line('---No data found in in_file table---');
    WHEN no_orders THEN
        dbms_output.put_line('---No orders data found---');
    WHEN OTHERS THEN
        dbms_output.put_line(sqlerrm);
END;

SET SERVEROUTPUT ON;

EXEC filter_order_inputs;

---------------------------------------------------------
----------------------PATIENT INSERT---------------------

CREATE OR REPLACE PROCEDURE ins_patient (
    in_first_name       IN VARCHAR2,
    in_last_name        IN VARCHAR2,
    in_gender           IN VARCHAR2,
    in_ssn              IN VARCHAR2,
    in_client_name      IN VARCHAR2,
    in_date_of_birth    IN DATE,
    in_insurance_status IN VARCHAR2
) AS

    var_client_id  NUMBER;
    var_date_check VARCHAR2(100);
    var_pat_cnt    NUMBER;
    cntssn         NUMBER := 0;
    unique_pat_id EXCEPTION;
    first_name_invalid EXCEPTION;
    last_name_invalid EXCEPTION;
    date_of_birth_invalid EXCEPTION;
    date_of_birth_invalid_1 EXCEPTION;
    gender_invalid EXCEPTION;
    ssn_unique EXCEPTION;
    client_name_invalid EXCEPTION;
    insurance_status_invalid EXCEPTION;
    client_not_found EXCEPTION;
    ssn_invalid_chars EXCEPTION;
    ssn_mal_formed EXCEPTION;
    ssn_null EXCEPTION;
    future_date EXCEPTION;
BEGIN
    IF in_client_name IS NULL OR VALIDATE_CONVERSION ( TRIM(in_client_name) AS NUMBER ) = 1 THEN
        RAISE client_name_invalid;
    ELSE
        BEGIN
            SELECT
                client_id
            INTO var_client_id
            FROM
                client
            WHERE
                    upper(TRIM(client_name)) = upper(TRIM(in_client_name))
                AND status = 'Active'
                AND is_deleted IS NULL;

        EXCEPTION
            WHEN no_data_found THEN
                RAISE client_not_found;
        END;
    END IF;

    IF in_ssn IS NULL THEN
        RAISE ssn_null;
    ELSIF regexp_instr(in_ssn, '^[0-9\-]*$') = 0 THEN
        RAISE ssn_invalid_chars;
    ELSIF regexp_instr(in_ssn, '^[0-9]{3}-[0-9]{2}-[0-9]{4}*$') = 0 THEN
        RAISE ssn_mal_formed;
    ELSIF in_ssn IS NOT NULL THEN
        SELECT
            COUNT(*)
        INTO cntssn
        FROM
            patient
        WHERE
                ssn = in_ssn
            AND is_deleted IS NULL;

        IF ( cntssn > 0 ) THEN
            RAISE ssn_unique;
        ELSE
            dbms_output.put_line('valid ssn');
        END IF;

    END IF;

    IF in_first_name IS NULL OR VALIDATE_CONVERSION ( in_first_name AS NUMBER ) = 1 THEN
        RAISE first_name_invalid;
    ELSIF
        regexp_like(in_first_name, '[[:alpha:]]')
        AND regexp_instr(in_first_name, '[0-9]') > 0
    THEN
        RAISE first_name_invalid;
    ELSIF in_last_name IS NULL OR VALIDATE_CONVERSION ( in_last_name AS NUMBER ) = 1 THEN
        RAISE last_name_invalid;
    ELSIF
        regexp_like(in_last_name, '[[:alpha:]]')
        AND regexp_instr(in_last_name, '[0-9]') > 0
    THEN
        RAISE last_name_invalid;
    ELSIF in_gender IS NULL OR upper(in_gender) NOT IN ( 'M', 'F', 'O' ) THEN
        RAISE gender_invalid;
    ELSIF in_date_of_birth IS NULL THEN
        RAISE date_of_birth_invalid;
    ELSIF date_check(in_date_of_birth) = 2 THEN
        RAISE future_date;
    ELSE
        SELECT
            COUNT(*)
        INTO var_pat_cnt
        FROM
            patient
        WHERE
                TRIM(first_name) = TRIM(in_first_name)
            AND TRIM(last_name) = TRIM(in_last_name)
            AND TRIM(gender) = TRIM(in_gender)
            AND TRIM(date_of_birth) = TRIM(in_date_of_birth)
            AND is_deleted IS NULL;

    END IF;

    IF ( var_pat_cnt > 0 ) THEN
        RAISE unique_pat_id;
    ELSIF in_insurance_status IS NULL THEN
        RAISE insurance_status_invalid;
    ELSIF upper(in_insurance_status) NOT IN ( 'INSURED', 'UNINSURED' ) THEN
        RAISE insurance_status_invalid;
    ELSE
        INSERT INTO patient (
            patient_id,
            first_name,
            last_name,
            patient_number,
            date_of_birth,
            gender,
            ssn,
            client_id,
            insurance_status,
            updated_date,
            created_date,
            is_deleted,
            delete_date,
            flag
        ) VALUES (
            sequence_primary_id.NEXTVAL,
            initcap(in_first_name),
            initcap(in_last_name),
            sequence_primary_id.NEXTVAL,
            in_date_of_birth,
            in_gender,
            in_ssn,
            var_client_id,
            initcap(in_insurance_status),
            sysdate,
            sysdate,
            NULL,
            NULL,
            'INS'
        );

        dbms_output.put_line('Patient is added');
        COMMIT;
    END IF;

EXCEPTION
    WHEN unique_pat_id THEN
        raise_application_error(-20001, 'Patient already exists in Database');
    WHEN first_name_invalid THEN
        raise_application_error(-20002, 'First Name is NUll or Invalid');
    WHEN last_name_invalid THEN
        raise_application_error(-20003, 'Last Name is NUll or Invalid');
    WHEN gender_invalid THEN
        raise_application_error(-20004, 'Gender should be M,F or O');
    WHEN ssn_unique THEN
        raise_application_error(-20005, 'SSN is NOT unique');
    WHEN date_of_birth_invalid THEN
        raise_application_error(-20006, 'Date of Birth is Invalid');
    WHEN client_name_invalid THEN
        raise_application_error(-20007, 'Client Name is Null or Invalid');
    WHEN insurance_status_invalid THEN
        raise_application_error(-20008, 'Insurance status should be Insured or Uninsured');
    WHEN client_not_found THEN
        raise_application_error(-20009, 'Client not found in database');
    WHEN ssn_invalid_chars THEN
        raise_application_error(-20011, 'SSN has invalid characters');
    WHEN ssn_mal_formed THEN
        raise_application_error(-20012, 'Mal-formed SSN  Number');
    WHEN ssn_null THEN
        raise_application_error(-20013, 'SSN  Number should not be null');
    WHEN future_date THEN
        raise_application_error(-20014, 'Date of Birth cannot be a future date');
        COMMIT;
END;
			
------------------------------------------------------------------------
-----------------------------PATIENT CONTACT INSERT---------------------
CREATE OR REPLACE PROCEDURE ins_pat_contact (
    in_patient_id   IN NUMBER,
    in_address      IN VARCHAR2,
    in_city         IN VARCHAR2,
    in_state        IN VARCHAR2,
    in_postal_code  IN VARCHAR2,
    in_phone_type   IN VARCHAR2, -- Not Mandatory
    in_phone_number IN VARCHAR2
) AS

    var_patient_id NUMBER;
    var_pat_cnt    NUMBER;
    unique_pat_id EXCEPTION;
    address_invalid EXCEPTION;
    city_invalid EXCEPTION;
    state_invalid EXCEPTION;
    postal_code_invalid EXCEPTION;
    phone_type_invalid EXCEPTION;
    phone_number_invalid EXCEPTION;
    phone_length_invalid EXCEPTION;
BEGIN
    IF in_address IS NULL THEN
        RAISE address_invalid;
    ELSIF in_city IS NULL THEN
        RAISE city_invalid;
    ELSIF in_state IS NULL THEN
        RAISE state_invalid;
    ELSIF
        in_state IS NOT NULL
        AND length(in_state) != 2
    THEN
        RAISE state_invalid;
    ELSIF in_postal_code IS NULL THEN
        RAISE postal_code_invalid;
    ELSIF VALIDATE_CONVERSION ( in_postal_code AS NUMBER ) = 0 THEN
        RAISE postal_code_invalid;
    ELSIF length(in_postal_code) <> 5 THEN
        RAISE postal_code_invalid;
    ELSIF in_phone_type IS NULL THEN
        RAISE phone_type_invalid;
    ELSIF
        in_phone_type IS NOT NULL
        AND upper(in_phone_type) NOT IN ( 'HOME', 'MOBILE', 'OFFICE' )
    THEN
        RAISE phone_type_invalid;
    ELSIF in_phone_number IS NULL THEN
        RAISE phone_number_invalid;
    ELSIF length(in_phone_number) <> 10 THEN
        RAISE phone_length_invalid;
    ELSIF VALIDATE_CONVERSION ( in_phone_number AS NUMBER ) = 0 THEN
        RAISE phone_number_invalid;
    ELSE
        SELECT
            COUNT(1)
        INTO var_patient_id
        FROM
            patient
        WHERE
            patient_id = in_patient_id;

        IF var_patient_id > 0 THEN
            INSERT INTO contact VALUES (
                sequence_primary_id.NEXTVAL,
                in_patient_id,
                in_address,
                initcap(in_city),
                upper(in_state),
                in_postal_code,
                initcap(in_phone_type),
                in_phone_number,
                sysdate,
                sysdate,
                NULL,
                NULL
            );
			COMMIT;
                -- do something here if exists
                --dbms_output.put_line('record exists.');
        ELSE
            RAISE unique_pat_id;
                -- do something here if not exists
                ---dbms_output.put_line('record does not exists.');
        END IF;

        COMMIT;
    END IF;
EXCEPTION
    WHEN unique_pat_id THEN
        raise_application_error(-20001, 'Patiet doesn''t exist in databse  Database');
    WHEN address_invalid THEN
        raise_application_error(-20001, 'Address should not be null or Invalid');
    WHEN city_invalid THEN
        raise_application_error(-20002, 'City should not be NUll');
    WHEN state_invalid THEN
        raise_application_error(-20003, 'State should not be NUll and length must be 2');
    WHEN postal_code_invalid THEN
        raise_application_error(-20003, 'Postal Code should not be Null and must be 5 digits');
    WHEN phone_type_invalid THEN
        raise_application_error(-20004, 'Phone type should be Mobile, Home or Office');
    WHEN phone_number_invalid THEN
        raise_application_error(-20005, 'Phone Number should not be Null or invalid');
    WHEN phone_length_invalid THEN
        raise_application_error(-20005, 'Phone Number length must be 10');
        COMMIT;
END;

-------------------------------------------------------------------------
--------------------------------PATIENT PRESCRIPTION---------------------

CREATE OR REPLACE PROCEDURE ins_pat_prescription (
    in_case_id      IN NUMBER,
    in_disease_name IN VARCHAR2,
    in_disease_type IN VARCHAR2
) AS
    cnt_medicine_id NUMBER;
    var_medicine_id NUMBER;
    var_case_id     NUMBER;
    case_id_invalid EXCEPTION;
    case_id_nad EXCEPTION;
    disease_name_null EXCEPTION;
BEGIN
    IF in_case_id IS NULL THEN
        RAISE case_id_invalid;
    ELSIF in_disease_name IS NULL THEN
        RAISE disease_name_null;
    ELSE
        dbms_output.put_line('Null check passed');
    END IF;

    SELECT
        COUNT(*)
    INTO var_case_id
    FROM
        case
    WHERE
        case_id = in_case_id;

    IF var_case_id = 1 THEN
        dbms_output.put_line('Case is found in database, Creating prescription');
        INSERT INTO prescription VALUES (
            sequence_primary_id.NEXTVAL,
            in_case_id,
            initcap(in_disease_name),
            initcap(in_disease_type),
            sysdate,
            sysdate,
            NULL,
            NULL
        );

        COMMIT;
    ELSE
        RAISE case_id_nad;
    END IF;

EXCEPTION
    WHEN disease_name_null THEN
        raise_application_error(-20001, 'Disease name is required');
    WHEN case_id_invalid THEN
        raise_application_error(-20002, 'Case id should not be null or invalid');
    WHEN case_id_nad THEN
        raise_application_error(-20003, 'Please Create the Case first');
        COMMIT;
END;

--------------------------------------------------------------------------------
---------------------------------INS PRESCRIBED MEDICINES-----------------------
CREATE OR REPLACE PROCEDURE ins_prescription_medicine (
    in_prescription_id IN NUMBER,
    in_medicine_name   IN VARCHAR2,
    in_manufacturer    IN VARCHAR2,
    in_quantity        IN NUMBER,
    in_strength        IN VARCHAR2
) AS

    cnt_medicine_id NUMBER := 0;
    var_medicine_id NUMBER;
    cnt_presc_id    NUMBER := 0;
    prescription_null EXCEPTION;
    medicine_name_null EXCEPTION;
    manufacturer_null EXCEPTION;
    quantity_null EXCEPTION;
    strength_null EXCEPTION;
    presc_not_available EXCEPTION;
	--medicine_name_NAD exception;
BEGIN
    IF in_prescription_id IS NULL THEN
        RAISE prescription_null;
    ELSIF in_medicine_name IS NULL THEN
        RAISE medicine_name_null;
    ELSIF in_manufacturer IS NULL THEN
        RAISE manufacturer_null;
    ELSIF in_quantity IS NULL THEN
        RAISE quantity_null;
    ELSIF in_strength IS NULL THEN
        RAISE strength_null;
    ELSE
        dbms_output.put_line('');
    END IF;

    SELECT
        COUNT(*)
    INTO cnt_presc_id
    FROM
        prescription
    WHERE
        prescription_id = in_prescription_id;

    IF cnt_presc_id = 0 THEN
        RAISE presc_not_available;
    END IF;
    SELECT
        COUNT(*)
    INTO cnt_medicine_id
    FROM
        medicines
    WHERE
            medicine_name = in_medicine_name
        AND manufacturer = TRIM(in_manufacturer)
        AND strength = TRIM(in_strength);

    IF ( cnt_medicine_id > 0 ) THEN
        SELECT
            medicine_id
        INTO var_medicine_id
        FROM
            medicines
        WHERE
                medicine_name = in_medicine_name
            AND manufacturer = TRIM(in_manufacturer)
            AND strength = TRIM(in_strength);

        dbms_output.put_line('Medicine found in approved list');
    ELSE
        dbms_output.put_line('Medicine not available in approved list, added to prescription');
    END IF;

    IF cnt_medicine_id > 0 OR cnt_medicine_id = 0 THEN
        INSERT INTO presc_medicine (
            order_med_id,
            prescription_id,
            medicine_id,
            quantity,
            strength,
            created_date,
            updated_date
        ) VALUES (
            sequence_next_key.NEXTVAL,
            in_prescription_id,
            var_medicine_id,
            in_quantity,
            in_strength,
            sysdate,
            sysdate
        );

        COMMIT;
    ELSE
        dbms_output.put_line('Rows not inserted');
    END IF;

    dbms_output.put_line('after if');
EXCEPTION
    WHEN prescription_null THEN
        raise_application_error(-20004, 'Prescription Name should not be null');
    WHEN medicine_name_null THEN
        raise_application_error(-20005, 'Medicine Name should not be null');
    WHEN manufacturer_null THEN
        raise_application_error(-20006, 'manufacturer should not be null');
    WHEN quantity_null THEN
        raise_application_error(-20007, 'quantity should not be null');
    WHEN strength_null THEN
        raise_application_error(-20008, 'strength should not be null');
    WHEN presc_not_available THEN
        raise_application_error(-20009, 'Prescription is not available in database');
        COMMIT;
END;

------------------------------------------------------------------------------------
---------------------------------CLAIMS APPROVAL------------------------------------
CREATE OR REPLACE PROCEDURE claims_approval (
    in_client_id       IN NUMBER,
    in_prescription_id IN NUMBER,
    in_claim_id        IN NUMBER
) AS

    cnt_med_id   NUMBER := 0;
    cnt_full_id  NUMBER := 0;
    cnt_id_check NUMBER := 0;
    cl_status    VARCHAR2(255);
    client_id_null EXCEPTION;
    prescription_id_null EXCEPTION;
    claim_id_null EXCEPTION;
    wrong_id_comb EXCEPTION;
    cl_staus_not_valid EXCEPTION;
BEGIN
    IF in_client_id IS NULL THEN
        RAISE client_id_null;
    ELSIF in_prescription_id IS NULL THEN
        RAISE prescription_id_null;
    ELSIF in_claim_id IS NULL THEN
        RAISE claim_id_null;
    ELSE
        dbms_output.put_line('NULL CHECK FAILED');
    END IF;

    SELECT
        COUNT(*)
    INTO cnt_id_check
    FROM
        claims
    WHERE
            claim_id = in_claim_id
        AND prescription_id = in_prescription_id
        AND client_id = in_client_id;

    IF cnt_id_check != 1 THEN
        RAISE wrong_id_comb;
    END IF;
    SELECT
        claim_status
    INTO cl_status
    FROM
        claims
    WHERE
            claim_id = in_claim_id
        AND prescription_id = in_prescription_id
        AND client_id = in_client_id;

    IF
        cnt_id_check = 1
        AND cl_status != 'New'
    THEN
        RAISE cl_staus_not_valid;
    END IF;
    WITH cte_temp1 AS (
        SELECT
            *
        FROM
            presc_medicine
        WHERE
            prescription_id = in_prescription_id
    )
    SELECT
        COUNT(*)
    INTO cnt_med_id
    FROM
        cte_temp1
    WHERE
        medicine_id IS NULL;

    WITH cte_temp2 AS (
        SELECT
            *
        FROM
            presc_medicine
        WHERE
            prescription_id = in_prescription_id
    )
    SELECT
        COUNT(*)
    INTO cnt_full_id
    FROM
        cte_temp2;

    IF
        cnt_med_id = 0
        AND cnt_full_id = 0
    THEN
        UPDATE claims
        SET
            claim_status = 'Invalid'
        WHERE
            claim_id = in_claim_id;

    ELSIF cnt_med_id = cnt_full_id THEN
        UPDATE claims
        SET
            claim_type = 'Partial',
            claim_status = 'Rejected'
        WHERE
            claim_id = in_claim_id;

    ELSIF
        cnt_med_id > 0
        AND cnt_med_id < cnt_full_id
    THEN
        UPDATE claims
        SET
            claim_type = 'Partial',
            claim_status = 'Approved'
        WHERE
            claim_id = in_claim_id;

    ELSE
        UPDATE claims
        SET
            claim_type = 'Complete',
            claim_status = 'Approved'
        WHERE
            claim_id = in_claim_id;

        COMMIT;
    END IF;

EXCEPTION
    WHEN client_id_null THEN
        raise_application_error(-20001, 'Client id should not be null');
    WHEN prescription_id_null THEN
        raise_application_error(-20002, 'Prescription is should not be null');
    WHEN claim_id_null THEN
        raise_application_error(-20003, 'Claim id should not be null');
    WHEN wrong_id_comb THEN
        raise_application_error(-20004, 'Prescription id,claims id and client id associated with each other');
    WHEN cl_staus_not_valid THEN
        raise_application_error(-20005, 'Claim status is not valid');
		commIT;
END;

----------------------------------------------------------------------------
---------------------------------CREATE Orders------------------------------
CREATE OR REPLACE PROCEDURE create_orders (
    in_prescription_id IN NUMBER,
    in_client_id       IN NUMBER,
    in_claim_status    IN VARCHAR2
) AS

    cnt_medicine_id      NUMBER := 0;
    var_case_id          NUMBER := 0;
    var_insurance_status VARCHAR2(255);
    prescription_null EXCEPTION;
    client_id_null EXCEPTION;
    claim_status_null EXCEPTION;
    claim_status_not_app EXCEPTION;
    CURSOR pres_med IS
    SELECT
        *
    FROM
        presc_medicine
    WHERE
            prescription_id = in_prescription_id
        AND medicine_id IS NOT NULL;

    pres_med_rec         presc_medicine%rowtype;
BEGIN
    IF in_claim_status != 'Approved' THEN
        RAISE claim_status_not_app;
    ELSIF in_prescription_id IS NULL THEN
        RAISE prescription_null;
    ELSIF in_client_id IS NULL THEN
        RAISE client_id_null;
    ELSIF in_claim_status IS NULL THEN
        RAISE claim_status_null;
    ELSE
        dbms_output.put_line('');
    END IF;

    SELECT
        case_id
    INTO var_case_id
    FROM
        prescription
    WHERE
        prescription_id = in_prescription_id;

    OPEN pres_med;
    LOOP
        FETCH pres_med INTO pres_med_rec;
        EXIT WHEN pres_med%notfound;
        INSERT INTO orders (
            order_id,
            order_status,
            case_id,
            ship_date,
            delivery_date,
            pharmacy_id,
            created_date,
            updated_date,
            is_deleted,
            delete_date,
            order_med_id
        ) VALUES (
            sequence_next_key.NEXTVAL,
            'New',
            var_case_id,
            NULL,
            NULL,
            allocate_pharmacy(in_client_id),
            sysdate,
            sysdate,
            NULL,
            NULL,
            pres_med_rec.order_med_id
        );

        COMMIT;
    END LOOP;

    CLOSE pres_med;
EXCEPTION
    WHEN prescription_null THEN
        raise_application_error(-20001, 'Prescription id should not be null');
    WHEN client_id_null THEN
        raise_application_error(-20002, 'Client id should not be null');
    WHEN claim_status_null THEN
        raise_application_error(-20003, 'Claim status should not be null');
    WHEN claim_status_not_app THEN
        raise_application_error(-20004, 'Claim is not approved');
        COMMIT;
END;