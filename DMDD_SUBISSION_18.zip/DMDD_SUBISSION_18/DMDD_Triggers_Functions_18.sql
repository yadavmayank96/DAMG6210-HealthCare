CREATE OR REPLACE FUNCTION status_update (
    o_id NUMBER
) RETURN NUMBER IS
    valid NUMBER := 2;
BEGIN
    UPDATE orders
    SET
        order_status = (
            SELECT
                order_status
            FROM
                in_file
            WHERE
                order_number = o_id
        )
    WHERE
        order_id = o_id;

    DELETE FROM in_file
    WHERE
        order_number = o_id;

    COMMIT;
    valid := 1;
    RETURN valid;
END;

-----------------------------------------------------------------

CREATE OR REPLACE FUNCTION error_records_transfer (
    o_id      NUMBER,
    p_id      NUMBER,
    error_txt VARCHAR
) RETURN NUMBER IS
    record_present NUMBER := 0;
    valid          NUMBER := 2;
BEGIN
    SELECT
        COUNT(*)
    INTO record_present
    FROM
        error_records
    WHERE
        order_number = o_id;

    IF record_present = 0 THEN
        INSERT INTO error_records (
            order_number,
            patient_number,
            error,
            err_desc,
            created_date,
            updated_date
        ) VALUES (
            o_id,
            p_id,
            error_txt,
            error_txt,
            sysdate,
            sysdate
        );

        DELETE FROM in_file
        WHERE
            order_number = o_id;

        valid := 1;
        COMMIT;
    ELSE
        DELETE FROM in_file
        WHERE
            order_number = o_id;

        valid := 2;
        COMMIT;
    END IF;

    RETURN valid;
EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20001, 'An error was encountered - '
                                        || sqlcode
                                        || ' -ERROR- '
                                        || sqlerrm);
END;

COMMIT;
-----------------------------------------------------------------

CREATE OR REPLACE FUNCTION date_check (
    change_date IN DATE
) RETURN NUMBER IS
    valid NUMBER := 2;
BEGIN
    IF change_date <= sysdate THEN
        valid := 1;
    END IF;
    RETURN valid;
END;

COMMIT;

------------------------------------------------------------------

CREATE OR REPLACE TRIGGER trg_ins_case AFTER
    INSERT ON patient
    FOR EACH ROW
BEGIN
    INSERT INTO case VALUES (
        sequence_primary_id.NEXTVAL,
        'New',
        :new.patient_id,
        sysdate,
        sysdate,
        NULL,
        NULL
    );
	commIT;

END;
/

CREATE OR REPLACE TRIGGER trg_upd_case AFTER
    UPDATE ON patient
    FOR EACH ROW
BEGIN
    INSERT INTO case VALUES (
        sequence_primary_id.NEXTVAL,
        'Re-visit',
        :new.patient_id,
        sysdate,
        sysdate,
        NULL,
        NULL
    );
	COMMit;

END;
/

CREATE OR REPLACE TRIGGER trg_ins_claims AFTER
    INSERT ON prescription
    FOR EACH ROW
BEGIN
    INSERT INTO claims VALUES (
        sequence_claim_id.NEXTVAL,
        'Claim Requested',
        'New',
        get_pat_client_id(:new.case_id),
        :new.prescription_id,
        sysdate,
        sysdate,
        NULL,
        NULL
    );
	commIT;

END;
/

CREATE OR REPLACE FUNCTION get_pat_client_id (
    i_case_id IN NUMBER
) RETURN NUMBER IS
    cli_id NUMBER;
BEGIN
    SELECT
        cl.client_id
    INTO cli_id
    FROM
        client cl
    WHERE
        cl.client_id = (
            SELECT
                p.client_id
            FROM
                patient p
            WHERE
                patient_id = (
                    SELECT
                        patient_id
                    FROM
                        case
                    WHERE
                        case_id = i_case_id
                )
        );

    RETURN cli_id;
END get_pat_client_id;
	
	
	CREATE OR REPLACE TRIGGER trg_claim_appproval AFTER
    INSERT ON claims
    FOR EACH ROW
	BEGIN
		IF :new.CLaim_sTATUS='New' then
		EXEC claims_approval (:new.client_ID,:new.prescription_id,:new.claim_id);
		end if;
	END;
	
	
		CREATE OR REPLACE TRIGGER trg_create_order AFTER
    UPDATE ON claims
    FOR EACH ROW
    declare
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
	IF upper(:new.CLAIM_status)='APPROVED' then
	create_orders(:new.prescription_id,:new.client_id,:new.claim_status);
	else
	dbms_output.put_line('Order will not be created');
	end if;
    commit;

END;
/


CREATE or REPLACE FUNCTION allocate_pharmacy(in_cLIENT_id NUMber)
	
		RETURN number IS
		pharma_id number;
    BEGIN
        IF In_cLIENT_id IN (1,4,6,8) then
		pharma_id :=64639;
		elsif In_cLIENT_id in (11,12,13,14) then
		pharma_id :=47322;
		elsif In_cLIENT_id in (15,16,18,19) then
		pharma_id :=46947;
		elsif In_cLIENT_id in (20,21,24) then
		pharma_id :=62012;
		else 
		SELECT pharmacy_id into pharma_id FROM pharmacy SAMPLE(1) where rownum=1 and UPPER(STATUS)='ACTIVE' and is_deleted is null;
		end if;
        RETURN pharma_id;
    END allocate_pharmacy;
	
create or replace function CHECK_DATE (
     p_date_string varchar2
)
return varchar2
is
l_date date;
l_date_string varchar2(10);
begin
l_date_string := p_date_string;

BEGIN
    l_date := to_date(p_date_string, 'MM/DD/YYYY');
EXCEPTION
    WHEN OTHERS THEN
        l_date_string := '000000';
END;

RETURN l_date_string;

end;
/

-----------------------------------
-----seQUENCE generatORS-----------

CREATE SEQUENCE  "SEQUENCE_CLAIM_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 700020 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
CREATE SEQUENCE  "SEQUENCE_NEXT_KEY"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 100011 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
CREATE SEQUENCE  "SEQUENCE_PRIMARY_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 501039 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;



	
